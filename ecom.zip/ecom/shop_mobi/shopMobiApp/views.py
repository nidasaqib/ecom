

from django.contrib import admin
from django.urls import path
from .views import Signup, Login, logout, Mobiles



urlpatterns = [

	path('signup', Signup.as_view(), name='signup'),
	path('login', Login.as_view(), name='login'),
	path('logout', logout, name='logout'),
  path('mobiles', Mobiles.as_view(), name='mobiles'),

]
