from django.db import models
'''Table structure:
users: id, username, email, password, number, address
mobiles: id, name, color, price, brand,model no, os, memory, ram
'''

class Userdetails(models.Model):
    username = models.CharField(max_length = 30)
    email = models.CharField(max_length = 30)
    password = models.CharField(max_length = 30)
    address = models.CharField(max_length = 50)
    number = models.CharField(max_length = 30)
    
    def __str__(self):
        return self.username

class Mobile(models.Model):
    name = models.CharField(max_length = 30)
    color = models.CharField(max_length = 30)
    price = models.CharField(max_length = 30)
    brand = models.CharField(max_length = 30)
    model = models.CharField(max_length = 30)
    os = models.CharField(max_length = 30)
    memory = models.CharField(max_length = 10)
    ram = models.CharField(max_length = 10)

	#album = models.ForeignKey(Album, on_delete = models.CASCADE)
    def __str__(self):
        return self.name

